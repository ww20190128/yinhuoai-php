<?php
// 5个选项    心芝的题目
return array (
  1 => 
  array (
    1 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你是一个时间观念很强的人 ',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '不是',
        ),
      ),
    ),
    2 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你时常容易流露或说出你的感觉和感情',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '不易流露感情',
        ),
      ),
    ),
    3 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你乐于拥有广泛的人际圈',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '如果可以选择的话，我更愿意一个人静静呆着',
        ),
      ),
    ),
    4 => 
    array (
      'groupName' => '性格类型',
      'matter' => '大多数时候，你倾向于',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '随机应变',
        ),
        'B' => 
        array (
          'name' => '事先计划',
        ),
      ),
    ),
    5 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你喜欢',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '有灵活性、较为松散的工作',
        ),
        'B' => 
        array (
          'name' => '有计划、有节奏的工作',
        ),
      ),
    ),
    6 => 
    array (
      'groupName' => '性格类型',
      'matter' => '比较而言，你更喜欢',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '逻辑缜密的侦探电影',
        ),
        'B' => 
        array (
          'name' => '轻松的家庭情感片',
        ),
      ),
    ),
    7 => 
    array (
      'groupName' => '性格类型',
      'matter' => '在日常生活中，对一些要做的小事，你通常',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '能清楚地记得',
        ),
        'B' => 
        array (
          'name' => '常会忘记它们，但是在重要的事情上从不含糊',
        ),
      ),
    ),
    8 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你的生活状态通常是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '尽量都事先做好准备，如约会、聚会、出游等',
        ),
        'B' => 
        array (
          'name' => '只要时机恰当就无拘无束地做任何有趣的事',
        ),
      ),
    ),
    9 => 
    array (
      'groupName' => '性格类型',
      'matter' => '从初次拜访的朋友家回来，你对那个家的印象是什么?',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '会想起某个细节，比如:“我喜欢客厅地毯的图案”',
        ),
        'B' => 
        array (
          'name' => '会记住一个笼统的感觉，比如:“感觉很温馨”',
        ),
      ),
    ),
    10 => 
    array (
      'groupName' => '性格类型',
      'matter' => '夜里你被一个噪声吵醒，很快噪声消失了，你',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '会起来找出原因才能再安睡',
        ),
        'B' => 
        array (
          'name' => '不会理会，接着睡去',
        ),
      ),
    ),
    11 => 
    array (
      'groupName' => '性格类型',
      'matter' => '在宴席中，你会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '很自然就与邻座攀谈起来',
        ),
        'B' => 
        array (
          'name' => '觉得不说话尴尬，但是又不知道说什么好',
        ),
      ),
    ),
    12 => 
    array (
      'groupName' => '性格类型',
      'matter' => '当一个朋友向你诉苦时，你会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '站在中立的局外人的立场来指出他的问题，以帮助他更客观地看待情况',
        ),
        'B' => 
        array (
          'name' => '站在他的立场上，用他想听的话共情并安慰他',
        ),
      ),
    ),
    13 => 
    array (
      'groupName' => '性格类型',
      'matter' => '在公共场合，如果你突然成为大家注意的中心，你会感到局促不安',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是',
        ),
        'B' => 
        array (
          'name' => '否',
        ),
      ),
    ),
    14 => 
    array (
      'groupName' => '性格类型',
      'matter' => '小时候，当你的父母外出时，你希望',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '他们仔细交代你做什么',
        ),
        'B' => 
        array (
          'name' => '他们不管你，让你自由活动',
        ),
      ),
    ),
    15 => 
    array (
      'groupName' => '性格类型',
      'matter' => '我常看到感人的电视或电影情景看到泪流不止',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '我很少因为这样的事情哭。只有在特别伤心的事发生再自己身上时才会哭',
        ),
      ),
    ),
    16 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你经常邀请朋友一起聚会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的，经常这样',
        ),
        'B' => 
        array (
          'name' => '不是的，我很少主动邀请',
        ),
      ),
    ),
    17 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你会受到广告的影响而冲动消费',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的，事后常会后悔',
        ),
        'B' => 
        array (
          'name' => '不是的，每一次下单都是我理性的决定',
        ),
      ),
    ),
    18 => 
    array (
      'groupName' => '性格类型',
      'matter' => '若你有时间和金钱，你的朋友邀请你到国外度假，并且在前一天才通知，你会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '必须先坚持我的时间表',
        ),
        'B' => 
        array (
          'name' => '立刻收拾行装',
        ),
      ),
    ),
    19 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你善于',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '记住方向和路线',
        ),
        'B' => 
        array (
          'name' => '没有导航就很容易迷路',
        ),
      ),
    ),
    20 => 
    array (
      'groupName' => '性格类型',
      'matter' => '要是事后知道某活动你没有被邀请，你会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '很不开心',
        ),
        'B' => 
        array (
          'name' => '没什么',
        ),
      ),
    ),
    21 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你看书通常会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '从头到尾、逐字逐句地阅读',
        ),
        'B' => 
        array (
          'name' => '经常快速浏览整本书，了解概貌，然后从中挑选出某些吸引你的部分认真阅读',
        ),
      ),
    ),
    22 => 
    array (
      'groupName' => '性格类型',
      'matter' => '哪个更可能是你的优点',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '照顾他人感受',
        ),
        'B' => 
        array (
          'name' => '行事有条理逻辑',
        ),
      ),
    ),
    23 => 
    array (
      'groupName' => '性格类型',
      'matter' => '喜欢受到他人的关心',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的，感觉旁边人在关心我的话，心情当然好咯',
        ),
        'B' => 
        array (
          'name' => '不，不要过分在意我',
        ),
      ),
    ),
    24 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你倾向',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '睡觉前想好明天做什么，会睡得很安稳',
        ),
        'B' => 
        array (
          'name' => '睡前想到明天有哪些哪些事情要做会让我感到紧迫，会睡不好',
        ),
      ),
    ),
    25 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你经常考虑人类及其命运问题',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '不会',
        ),
      ),
    ),
    26 => 
    array (
      'groupName' => '性格类型',
      'matter' => '当你尝试了解某些事情时，一般你会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '先要了解细节',
        ),
        'B' => 
        array (
          'name' => '先了解整体情况，细节容后再谈',
        ),
      ),
    ),
    27 => 
    array (
      'groupName' => '性格类型',
      'matter' => '哪个形容词更贴合你的性格：',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '热情',
        ),
        'B' => 
        array (
          'name' => '安静',
        ),
      ),
    ),
    28 => 
    array (
      'groupName' => '性格类型',
      'matter' => '哪种更符合你',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '我很少质询和指责他人，更愿意做一个随和与包容的人',
        ),
        'B' => 
        array (
          'name' => '我不想充当老好人，发现他人犯错就会直言不讳指出来',
        ),
      ),
    ),
    29 => 
    array (
      'groupName' => '性格类型',
      'matter' => '哪种更符合你',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '表面传统，其实内心是开放而热烈的，渴望挑战自己',
        ),
        'B' => 
        array (
          'name' => '表面很开放，但只是想做自己，内心其实是保守而传统的',
        ),
      ),
    ),
    30 => 
    array (
      'groupName' => '性格类型',
      'matter' => '童年时，从学校回家，你往往会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '主动诉说学校发生的事情',
        ),
        'B' => 
        array (
          'name' => '很少说学校的事，除非被问',
        ),
      ),
    ),
    31 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你觉得大部分人基本上是心怀善意的',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是',
        ),
        'B' => 
        array (
          'name' => '否',
        ),
      ),
    ),
    32 => 
    array (
      'groupName' => '性格类型',
      'matter' => '准备搭车远行时，哪种更符合你',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '临行前才匆匆忙忙收拾，赶到车站车已经差不多要出发了...谁叫我是个慢性子呢',
        ),
        'B' => 
        array (
          'name' => '早早收拾好行李，第二天提前很早就去到车站，发现你是第一个来候车的人',
        ),
      ),
    ),
    33 => 
    array (
      'groupName' => '性格类型',
      'matter' => '请选择更合适描述你的词语',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '我会突然尝试做某些事，看看会有什么事情发生',
        ),
        'B' => 
        array (
          'name' => '我尝试做任何事前，都想事先知道可能有什么事情发生',
        ),
      ),
    ),
    34 => 
    array (
      'groupName' => '性格类型',
      'matter' => '碰到熟人，下意识躲避',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '常常这样',
        ),
        'B' => 
        array (
          'name' => '不常这样',
        ),
      ),
    ),
    35 => 
    array (
      'groupName' => '性格类型',
      'matter' => '当你感到疲惫或压力时',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '会去找朋友聚会或参加社交活动来给自己减压',
        ),
        'B' => 
        array (
          'name' => '更喜欢待在家里看书、看电视，或静思来恢复精神',
        ),
      ),
    ),
    36 => 
    array (
      'groupName' => '性格类型',
      'matter' => '生活中，你往往',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '容易批评人',
        ),
        'B' => 
        array (
          'name' => '容易表扬人',
        ),
      ),
    ),
    37 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你会:',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '我常常会有一些新的点子冒出来，对一些事情的解决总觉得有更好的办法',
        ),
        'B' => 
        array (
          'name' => '关注实实在在的人和物',
        ),
      ),
    ),
    38 => 
    array (
      'groupName' => '性格类型',
      'matter' => '马上能叫出五个朋友的名字',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '不要说是5个，让我说出10个人也没问题呀',
        ),
        'B' => 
        array (
          'name' => '突然让我叫出5个人的名字，想不起来呀！天啊，难道我朋友这么少吗',
        ),
      ),
    ),
    39 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你已经完成性格类型的测试，接下来还需测试您的爱情观和婚姻观，请继续',
      'scoreValue' => '',
      'matterImg' => 'https://oss.1cece.top/storage/uploads/20231209/77a2d18210393e1441d5f95979afe35c.jpg',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '继续测试',
        ),
      ),
    ),
    40 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '在约会中，更符合我的是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '大部分时候我在说',
        ),
        'B' => 
        array (
          'name' => '大部分时候我在听',
        ),
      ),
    ),
    41 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '点餐的时候，你',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '会很快根据自己喜爱的口味决定要点什么',
        ),
        'B' => 
        array (
          'name' => '经常在点菜前花时间向服务员问很多问题，尝试新品',
        ),
      ),
    ),
    42 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '如果别人想要了解我，通常会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '不用太长时间，一小段时日即可',
        ),
        'B' => 
        array (
          'name' => '需要很长时间',
        ),
      ),
    ),
    43 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '约会之前，我更可能是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '想象一大堆关于即将来临之约会的事情',
        ),
        'B' => 
        array (
          'name' => '只期待它的自然发生',
        ),
      ),
    ),
    44 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '我留给异性的印象一般是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '感性的',
        ),
        'B' => 
        array (
          'name' => '理性的',
        ),
      ),
    ),
    45 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '恋爱时，你一般更喜欢',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '面对面的、口头的交流而不是在网上交流',
        ),
        'B' => 
        array (
          'name' => '更喜欢在网上交流，如微信文字交流',
        ),
      ),
    ),
    46 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '恋爱中的你，大多数时候更倾向于：',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '独处',
        ),
        'B' => 
        array (
          'name' => '同伴侣在一起',
        ),
      ),
    ),
    47 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '恋爱中你常会站在对方角度去思考而模糊了自己的立场',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '不会',
        ),
      ),
    ),
    48 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '恋爱中，你发现很难谈论自己的情感',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是这样',
        ),
        'B' => 
        array (
          'name' => '不是',
        ),
      ),
    ),
    49 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '以下听起来更吸引我的是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '与恋人一起去好玩、热闹的地方',
        ),
        'B' => 
        array (
          'name' => '与恋人在家做一些简单的事情，例如看一部经典的电影，共同制作精致的美食等',
        ),
      ),
    ),
    50 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '在你的生活方式中，你比较喜欢',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '别出心裁',
        ),
        'B' => 
        array (
          'name' => '根据惯例',
        ),
      ),
    ),
    51 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '你容易将你的私事和情感',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '和别人分享',
        ),
        'B' => 
        array (
          'name' => '尽可能隐藏',
        ),
      ),
    ),
    52 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '情感因素很难左右你的决定',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是',
        ),
        'B' => 
        array (
          'name' => '否',
        ),
      ),
    ),
    53 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '当我和一个人交往时，我更看重',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '情感上的相容性：能互相理解和支持',
        ),
        'B' => 
        array (
          'name' => '智慧上的相容性：能在思想上对话，客观地讨论、辩论事情',
        ),
      ),
    ),
    54 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '被邀请参加同学的婚礼，发现婚礼上除了同学都没有认识的人。你是否会觉得有些不自在？',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是',
        ),
        'B' => 
        array (
          'name' => '否',
        ),
      ),
    ),
    55 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '在看一场电影之前',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '先看一下它的介绍和预告',
        ),
        'B' => 
        array (
          'name' => '想要保持惊喜，不会主动关注它的资讯',
        ),
      ),
    ),
    56 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '在与他人的第一次聚会中，若我约的人来迟了',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '我会不太高兴',
        ),
        'B' => 
        array (
          'name' => '不太在乎，因为我偶尔也会迟到',
        ),
      ),
    ),
    57 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '对于应酬中逢场作戏、聪明圆融的人，你的看法是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '不理解，也无法接受人们快速地相熟热络，而又骨底淡薄',
        ),
        'B' => 
        array (
          'name' => '看应酬的目的是什么，只要目的是有益的，这些也都无所谓了',
        ),
      ),
    ),
    58 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '当你受委屈时',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '需要找人倾诉',
        ),
        'B' => 
        array (
          'name' => '宁愿憋在心里或匿名写在网上吐嘈',
        ),
      ),
    ),
    59 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '当受到情感上的伤害或挫折时',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '虽然我觉得受伤，但一旦想通，就会很快从阴影中走出来',
        ),
        'B' => 
        array (
          'name' => '我通常让自己的情绪深陷其中，很难走出来',
        ),
      ),
    ),
    60 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '当我不同意恋人的想法时，我更倾向于',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '尽可能避免伤害对方的感情，若是会对对方造成伤害的话，我宁愿不说',
        ),
        'B' => 
        array (
          'name' => '毫无保留地说话，并且对恋人直言直语，因为对的就是对的',
        ),
      ),
    ),
    61 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '只要有爱，什么都可以原谅',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '不认同，就算相爱，凡事都是有分寸的',
        ),
        'B' => 
        array (
          'name' => '认同，爱情能冲淡一切不快',
        ),
      ),
    ),
    62 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '哪种意境更符合你',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '人生就像一场旅行不必在意目的地在乎的是沿途的风景和看风景的心情',
        ),
        'B' => 
        array (
          'name' => '人生需要树立目标并为之奋斗，专注人生目标的人往往无暇欣赏路途美景',
        ),
      ),
    ),
    63 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '哪种情形更符合你',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '对于传统的东西，我遵循弃其糟粕，取其精华的原则',
        ),
        'B' => 
        array (
          'name' => '必须承认潜意识中我还是会受到传统观念的束缚，但也会因此而受益',
        ),
      ),
    ),
    64 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '你跟你女朋友感情很好，到了谈婚论嫁的时候，女方父母要求的彩礼你满足不了，你会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '考虑放弃这段恋情，因为爱情是爱情，婚姻是婚姻',
        ),
        'B' => 
        array (
          'name' => '想尽一切办法也要在一起，相信我们的感情总有一天会获得女方父母的认可',
        ),
      ),
    ),
    65 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '下列两个异性，如果让你选择，你最终会选择和谁在一起？',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '家庭背景和经济实力门当户对，但不心动的人',
        ),
        'B' => 
        array (
          'name' => '很有感觉，但家庭背景和经济实力和你有差距的人',
        ),
      ),
    ),
    66 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '你已经完成爱情婚姻观的测试，接下来还需测试您的职业性格，请继续',
      'scoreValue' => '',
      'matterImg' => 'https://oss.1cece.top/storage/uploads/20231209/21bf328f397b8b6c95bf2be420c4ff00.jpg',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '继续测试',
        ),
      ),
    ),
    67 => 
    array (
      'groupName' => '职业性格',
      'matter' => '如果让你完成一个手工，你希望随心所欲地创作',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的，这样才可以让我有所发挥',
        ),
        'B' => 
        array (
          'name' => '不是的，没有相应的参考样式，我会感觉很难',
        ),
      ),
    ),
    68 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你更喜欢怎样的氛围下工作:',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '相处和睦而舒服',
        ),
        'B' => 
        array (
          'name' => '有竞争有挑战',
        ),
      ),
    ),
    69 => 
    array (
      'groupName' => '职业性格',
      'matter' => '周末或者假期，你一般:',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '经常会睡到中午，一天只吃两餐',
        ),
        'B' => 
        array (
          'name' => '也会早早起床，保持一日三餐的规律性',
        ),
      ),
    ),
    70 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你在工作中',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '会关注周围发生的任何事',
        ),
        'B' => 
        array (
          'name' => '一般只关注自己的工作',
        ),
      ),
    ),
    71 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你有时候会心血来潮做一件事情',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '极少会这样',
        ),
      ),
    ),
    72 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你不会为了你所在的群体利益而牺牲自己的利益',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是',
        ),
        'B' => 
        array (
          'name' => '否',
        ),
      ),
    ),
    73 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你习惯投入更多的注意力在...上',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '(这)是什么',
        ),
        'B' => 
        array (
          'name' => '为什么(会是这样)',
        ),
      ),
    ),
    74 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你的兴趣',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '很广泛，但不太深入',
        ),
        'B' => 
        array (
          'name' => '会对某些非常感兴趣的深入研究',
        ),
      ),
    ),
    75 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你一般会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '先把工作或作业完成好再玩',
        ),
        'B' => 
        array (
          'name' => '尽可能忙里偷闲地娱乐',
        ),
      ),
    ),
    76 => 
    array (
      'groupName' => '职业性格',
      'matter' => '在做某些很多人在做的事情时，你比较喜欢',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '以一般人所接受的方式进行',
        ),
        'B' => 
        array (
          'name' => '以自创的方式进行',
        ),
      ),
    ),
    77 => 
    array (
      'groupName' => '职业性格',
      'matter' => '大多时候，你的书桌或办公桌面物件的摆放更多是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '有序的',
        ),
        'B' => 
        array (
          'name' => '随意的',
        ),
      ),
    ),
    78 => 
    array (
      'groupName' => '职业性格',
      'matter' => '对你来说，同时进行多项任务不是件难事',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的，甚至可能会享受其中',
        ),
        'B' => 
        array (
          'name' => '不是的，这样会打乱我做事的节奏',
        ),
      ),
    ),
    79 => 
    array (
      'groupName' => '职业性格',
      'matter' => '童年上学时',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '爱主动举手提问或回答问题',
        ),
        'B' => 
        array (
          'name' => '只有被老师点名时才发言',
        ),
      ),
    ),
    80 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你是个意志坚强的人吗',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '不是的，我还有挺多软弱退缩的时候',
        ),
      ),
    ),
    81 => 
    array (
      'groupName' => '职业性格',
      'matter' => '在和别人合作做事的时候，你最怕别人说',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '根据我的经验',
        ),
        'B' => 
        array (
          'name' => '据我推理',
        ),
      ),
    ),
    82 => 
    array (
      'groupName' => '职业性格',
      'matter' => '哪种更符合你',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '过于抽象，因此可能在必要的后续行动上不切实际',
        ),
        'B' => 
        array (
          'name' => '谨小慎微，可能导致视野不开阔',
        ),
      ),
    ),
    83 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你容易陷入情绪化不能自拔吗',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是',
        ),
        'B' => 
        array (
          'name' => '否',
        ),
      ),
    ),
    84 => 
    array (
      'groupName' => '职业性格',
      'matter' => '当你专注做某件事情的时候',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '需要不时停下来休息',
        ),
        'B' => 
        array (
          'name' => '不希望受到任何干扰，持续下去',
        ),
      ),
    ),
    85 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你参与社交聚会时',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '总是能认识新朋友',
        ),
        'B' => 
        array (
          'name' => '只跟几个熟识好友呆在一起',
        ),
      ),
    ),
    86 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你会倾向',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '在自己有兴趣的范畴，持续积累丰富的经验',
        ),
        'B' => 
        array (
          'name' => '在不同的领域拥有各式各样不同的经验',
        ),
      ),
    ),
    87 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你容易被强烈的情感影响',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是这样',
        ),
        'B' => 
        array (
          'name' => '不会',
        ),
      ),
    ),
    88 => 
    array (
      'groupName' => '职业性格',
      'matter' => '他人违反规定，你更可能',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '按照章程办事，因为是我的职责要求',
        ),
        'B' => 
        array (
          'name' => '视实际情况而定，因为规矩是死的，而人是活的',
        ),
      ),
    ),
    89 => 
    array (
      'groupName' => '职业性格',
      'matter' => '很容易与他人成为朋友',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的，不管对方是谁，我都能和他和睦相处',
        ),
        'B' => 
        array (
          'name' => '没有必要和所有人都成为朋友，有几个真正的知己就可以',
        ),
      ),
    ),
    90 => 
    array (
      'groupName' => '职业性格',
      'matter' => '我喜欢的处事方式是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '坚持那些已经有效的做法',
        ),
        'B' => 
        array (
          'name' => '分析哪些仍有错或不完善，优化以往的做法',
        ),
      ),
    ),
    91 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你更擅长',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '运用逻辑、分析及批判性思维来解决问题',
        ),
        'B' => 
        array (
          'name' => '运用人际关系解决问题',
        ),
      ),
    ),
    92 => 
    array (
      'groupName' => '职业性格',
      'matter' => '一个人应该',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '考虑人生的真正意义',
        ),
        'B' => 
        array (
          'name' => '踏踏实实地工作和学习',
        ),
      ),
    ),
    93 => 
    array (
      'groupName' => '职业性格',
      'matter' => '在一群人中，你是那个:',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '擅于把气氛营造出来的人',
        ),
        'B' => 
        array (
          'name' => '不多说话，更像以”观察者“身份参与的人',
        ),
      ),
    ),
    94 => 
    array (
      'groupName' => '职业性格',
      'matter' => '如你有一个约见，你是习惯临场发挥还是事先周密准备',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '随机应变，临场发挥',
        ),
        'B' => 
        array (
          'name' => '不周密准备我不安心',
        ),
      ),
    ),
    95 => 
    array (
      'groupName' => '职业性格',
      'matter' => '请选择更合适描述你的词语',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '擅长在变化中寻求挑战',
        ),
        'B' => 
        array (
          'name' => '习惯一步一个脚印稳步前行',
        ),
      ),
    ),
    96 => 
    array (
      'groupName' => '职业性格',
      'matter' => '请选择更合适描述你的词语',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '我通常边说话，边思考',
        ),
        'B' => 
        array (
          'name' => '我在说话前，通常会思考要说的话',
        ),
      ),
    ),
    97 => 
    array (
      'groupName' => '职业性格',
      'matter' => '无所事事的时候，你会:',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '觉得很无聊，有种浪费生命的感觉',
        ),
        'B' => 
        array (
          'name' => '很享受这种闲暇的情致',
        ),
      ),
    ),
    98 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你比较钦羡',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '循规蹈矩、不引人注目的人',
        ),
        'B' => 
        array (
          'name' => '特立独行的人',
        ),
      ),
    ),
    99 => 
    array (
      'groupName' => '职业性格',
      'matter' => '在人际交往时，你:',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '希望在人际关系中占据主导地位',
        ),
        'B' => 
        array (
          'name' => '顺其自然，不温不火，相对被动',
        ),
      ),
    ),
    100 => 
    array (
      'groupName' => '职业性格',
      'matter' => '电话铃声突然响起或类似这样的突发性事件，你习惯最先做出回应',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '不会',
        ),
      ),
    ),
    101 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你需要有挑战的，高技术含量的工作',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '不是的',
        ),
        'B' => 
        array (
          'name' => '是的',
        ),
      ),
    ),
    102 => 
    array (
      'groupName' => '职业性格',
      'matter' => '喜欢清闲的生活',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的，我喜欢轻轻松松的人生',
        ),
        'B' => 
        array (
          'name' => '我喜欢有挑战的人生，不断给自己更高的目标',
        ),
      ),
    ),
    103 => 
    array (
      'groupName' => '职业性格',
      'matter' => '我更愿意被看作是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '务实的人',
        ),
        'B' => 
        array (
          'name' => '有想象力、有灵感的人',
        ),
      ),
    ),
    104 => 
    array (
      'groupName' => '职业性格',
      'matter' => '做某个项目，你更喜欢',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '最后完成的结果',
        ),
        'B' => 
        array (
          'name' => '享受过程',
        ),
      ),
    ),
    105 => 
    array (
      'groupName' => '职业性格',
      'matter' => '终测题：你更像下面的哪一边',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '<p>相比推测，更重视证据，并相信自己的亲身经历和经验</p><p>重视规则和标准，擅长设定目标、制定决策和组织资源来完成任务。</p><p>希望实现高效的生产力，认为只有将人员和系统合理地组织起来，才能最好地实现这一目标。</p>',
        ),
        'B' => 
        array (
          'name' => '<p>乐于了解游戏规则，更看重可预测性而非想象力，并且依靠过去的经验来指导自己。</p><p>逻辑性强，有条不紊，享受利用逐步推理的方法来解决问题的任务。</p><p>对细节一丝不苟，对事物进行仔细检查以确保其正确性。</p>',
        ),
      ),
    ),
  ),
  2 => 
  array (
    1 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你是一个时间观念很强的人',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '不是',
        ),
      ),
    ),
    2 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你时常容易流露或说出你的感觉和感情',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '不易流露感情',
        ),
      ),
    ),
    3 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你乐于拥有广泛的人际圈',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '如果可以选择的话，我更愿意一个人静静呆着',
        ),
      ),
    ),
    4 => 
    array (
      'groupName' => '性格类型',
      'matter' => '大多数时候，你倾向于',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '随机应变',
        ),
        'B' => 
        array (
          'name' => '事先计划',
        ),
      ),
    ),
    5 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你喜欢',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '有灵活性、较为松散的工作',
        ),
        'B' => 
        array (
          'name' => '有计划、有节奏的工作',
        ),
      ),
    ),
    6 => 
    array (
      'groupName' => '性格类型',
      'matter' => '比较而言，你更喜欢',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '逻辑缜密的侦探电影',
        ),
        'B' => 
        array (
          'name' => '轻松的家庭情感片',
        ),
      ),
    ),
    7 => 
    array (
      'groupName' => '性格类型',
      'matter' => '在日常生活中，对一些要做的小事，你通常',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '能清楚地记得',
        ),
        'B' => 
        array (
          'name' => '常会忘记它们，但是在重要的事情上从不含糊',
        ),
      ),
    ),
    8 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你的生活状态通常是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '尽量都事先做好准备，如约会、聚会、出游等',
        ),
        'B' => 
        array (
          'name' => '只要时机恰当就无拘无束地做任何有趣的事',
        ),
      ),
    ),
    9 => 
    array (
      'groupName' => '性格类型',
      'matter' => '从初次拜访的朋友家回来，你对那个家的印象是什么?',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '会想起某个细节，比如:“我喜欢客厅地毯的图案”',
        ),
        'B' => 
        array (
          'name' => '会记住一个笼统的感觉，比如:“感觉很温馨”',
        ),
      ),
    ),
    10 => 
    array (
      'groupName' => '性格类型',
      'matter' => '夜里你被一个噪声吵醒，很快噪声消失了，你',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '会起来找出原因才能再安睡',
        ),
        'B' => 
        array (
          'name' => '不会理会，接着睡去',
        ),
      ),
    ),
    11 => 
    array (
      'groupName' => '性格类型',
      'matter' => '在宴席中，你会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '很自然就与邻座攀谈起来',
        ),
        'B' => 
        array (
          'name' => '觉得不说话尴尬，但是又不知道说什么好',
        ),
      ),
    ),
    12 => 
    array (
      'groupName' => '性格类型',
      'matter' => '当一个朋友向你诉苦时，你会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '站在中立的局外人的立场来指出他的问题，以帮助他更客观地看待情况',
        ),
        'B' => 
        array (
          'name' => '站在他的立场上，用他想听的话共情并安慰他',
        ),
      ),
    ),
    13 => 
    array (
      'groupName' => '性格类型',
      'matter' => '在公共场合，如果你突然成为大家注意的中心，你会感到局促不安',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是',
        ),
        'B' => 
        array (
          'name' => '否',
        ),
      ),
    ),
    14 => 
    array (
      'groupName' => '性格类型',
      'matter' => '小时候，当你的父母外出时，你希望',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '他们仔细交代你做什么',
        ),
        'B' => 
        array (
          'name' => '他们不管你，让你自由活动',
        ),
      ),
    ),
    15 => 
    array (
      'groupName' => '性格类型',
      'matter' => '我常看到感人的电视或电影情景看到泪流不止',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '我很少因为这样的事情哭。只有在特别伤心的事发生再自己身上时才会哭',
        ),
      ),
    ),
    16 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你经常邀请朋友一起聚会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的，经常这样',
        ),
        'B' => 
        array (
          'name' => '不是的，我很少主动邀请',
        ),
      ),
    ),
    17 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你会受到广告的影响而冲动消费',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的，事后常会后悔',
        ),
        'B' => 
        array (
          'name' => '不是的，每一次下单都是我理性的决定',
        ),
      ),
    ),
    18 => 
    array (
      'groupName' => '性格类型',
      'matter' => '若你有时间和金钱，你的朋友邀请你到国外度假，并且在前一天才通知，你会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '必须先坚持我的时间表',
        ),
        'B' => 
        array (
          'name' => '立刻收拾行装',
        ),
      ),
    ),
    19 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你善于',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '记住方向和路线',
        ),
        'B' => 
        array (
          'name' => '没有导航就很容易迷路',
        ),
      ),
    ),
    20 => 
    array (
      'groupName' => '性格类型',
      'matter' => '要是事后知道某活动你没有被邀请，你会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '很不开心',
        ),
        'B' => 
        array (
          'name' => '没什么',
        ),
      ),
    ),
    21 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你看书通常会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '从头到尾、逐字逐句地阅读',
        ),
        'B' => 
        array (
          'name' => '经常快速浏览整本书，了解概貌，然后从中挑选出某些吸引你的部分认真阅读',
        ),
      ),
    ),
    22 => 
    array (
      'groupName' => '性格类型',
      'matter' => '哪个更可能是你的优点',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '照顾他人感受',
        ),
        'B' => 
        array (
          'name' => '行事有条理逻辑',
        ),
      ),
    ),
    23 => 
    array (
      'groupName' => '性格类型',
      'matter' => '喜欢受到他人的关心',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的，感觉旁边人在关心我的话，心情当然好咯',
        ),
        'B' => 
        array (
          'name' => '不，不要过分在意我',
        ),
      ),
    ),
    24 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你倾向',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '睡觉前想好明天做什么，会睡得很安稳',
        ),
        'B' => 
        array (
          'name' => '睡前想到明天有哪些哪些事情要做会让我感到紧迫，会睡不好',
        ),
      ),
    ),
    25 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你经常考虑人类及其命运问题',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '不会',
        ),
      ),
    ),
    26 => 
    array (
      'groupName' => '性格类型',
      'matter' => '当你尝试了解某些事情时，一般你会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '先要了解细节',
        ),
        'B' => 
        array (
          'name' => '先了解整体情况，细节容后再谈',
        ),
      ),
    ),
    27 => 
    array (
      'groupName' => '性格类型',
      'matter' => '哪个形容词更贴合你的性格：',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '热情',
        ),
        'B' => 
        array (
          'name' => '安静',
        ),
      ),
    ),
    28 => 
    array (
      'groupName' => '性格类型',
      'matter' => '哪种更符合你',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '我很少质询和指责他人，更愿意做一个随和与包容的人',
        ),
        'B' => 
        array (
          'name' => '我不想充当老好人，发现他人犯错就会直言不讳指出来',
        ),
      ),
    ),
    29 => 
    array (
      'groupName' => '性格类型',
      'matter' => '哪种更符合你',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '表面传统，其实内心是开放而热烈的，渴望挑战自己',
        ),
        'B' => 
        array (
          'name' => '表面很开放，但只是想做自己，内心其实是保守而传统的',
        ),
      ),
    ),
    30 => 
    array (
      'groupName' => '性格类型',
      'matter' => '童年时，从学校回家，你往往会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '主动诉说学校发生的事情',
        ),
        'B' => 
        array (
          'name' => '很少说学校的事，除非被问',
        ),
      ),
    ),
    31 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你觉得大部分人基本上是心怀善意的',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是',
        ),
        'B' => 
        array (
          'name' => '否',
        ),
      ),
    ),
    32 => 
    array (
      'groupName' => '性格类型',
      'matter' => '准备搭车远行时，哪种更符合你',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '临行前才匆匆忙忙收拾，赶到车站车已经差不多要出发了...谁叫我是个慢性子呢',
        ),
        'B' => 
        array (
          'name' => '早早收拾好行李，第二天提前很早就去到车站，发现你是第一个来候车的人',
        ),
      ),
    ),
    33 => 
    array (
      'groupName' => '性格类型',
      'matter' => '请选择更合适描述你的词语',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '我会突然尝试做某些事，看看会有什么事情发生',
        ),
        'B' => 
        array (
          'name' => '我尝试做任何事前，都想事先知道可能有什么事情发生',
        ),
      ),
    ),
    34 => 
    array (
      'groupName' => '性格类型',
      'matter' => '碰到熟人，下意识躲避',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '常常这样',
        ),
        'B' => 
        array (
          'name' => '不常这样',
        ),
      ),
    ),
    35 => 
    array (
      'groupName' => '性格类型',
      'matter' => '当你感到疲惫或压力时',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '会去找朋友聚会或参加社交活动来给自己减压',
        ),
        'B' => 
        array (
          'name' => '更喜欢待在家里看书、看电视，或静思来恢复精神',
        ),
      ),
    ),
    36 => 
    array (
      'groupName' => '性格类型',
      'matter' => '生活中，你往往',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '容易批评人',
        ),
        'B' => 
        array (
          'name' => '容易表扬人',
        ),
      ),
    ),
    37 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你会:',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '我常常会有一些新的点子冒出来，对一些事情的解决总觉得有更好的办法',
        ),
        'B' => 
        array (
          'name' => '关注实实在在的人和物',
        ),
      ),
    ),
    38 => 
    array (
      'groupName' => '性格类型',
      'matter' => '马上能叫出五个朋友的名字',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '不要说是5个，让我说出10个人也没问题呀',
        ),
        'B' => 
        array (
          'name' => '突然让我叫出5个人的名字，想不起来呀！天啊，难道我朋友这么少吗',
        ),
      ),
    ),
    39 => 
    array (
      'groupName' => '性格类型',
      'matter' => '你已经完成性格类型的测试，接下来还
需测试您的爱情观和婚姻观，请继续',
      'scoreValue' => '',
      'matterImg' => 'https://oss.1cece.top/storage/uploads/20231209/793b0f360e6cf0f991c397b04a02a3d3.jpg',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '继续测试',
        ),
      ),
    ),
    40 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '约会之前，我更可能是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '想象一大堆关于即将来临之约会的事情',
        ),
        'B' => 
        array (
          'name' => '只期待它的自然发生',
        ),
      ),
    ),
    41 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '当我和一个人交往时，我更看重',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '情感上的相容性：能互相理解和支持',
        ),
        'B' => 
        array (
          'name' => '智慧上的相容性：能在思想上对话，客观地讨论、辩论事情',
        ),
      ),
    ),
    42 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '你偏好',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '事先知道约会的行程：要去哪里、有谁参加、你会在那里多久',
        ),
        'B' => 
        array (
          'name' => '让约会自然地发生，不做太多事先的计划',
        ),
      ),
    ),
    43 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '在看一场电影之前',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '先看一下它的介绍和预告',
        ),
        'B' => 
        array (
          'name' => '想要保持惊喜，不会主动关注它的资讯',
        ),
      ),
    ),
    44 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '当遇到聚会中第一次见面的人对你很热情时，你会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '很高兴，情绪会受到感染，并对其产生好感',
        ),
        'B' => 
        array (
          'name' => '热情应付，但心存一丝疑虑：对方为什么要这样热情，是否有其他目的',
        ),
      ),
    ),
    45 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '在与他人的第一次聚会中，若我约的人来迟了',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '我会不太高兴',
        ),
        'B' => 
        array (
          'name' => '不太在乎，因为我偶尔也会迟到',
        ),
      ),
    ),
    46 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '恋爱中的你，大多数时候更倾向于：',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '独处',
        ),
        'B' => 
        array (
          'name' => '同伴侣在一起',
        ),
      ),
    ),
    47 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '以下听起来更吸引我的是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '与恋人一起去好玩、热闹的地方',
        ),
        'B' => 
        array (
          'name' => '与恋人在家做一些简单的事情，例如看一部经典的电影，共同制作精致的美食等',
        ),
      ),
    ),
    48 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '和伴侣相处，你更',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '需要安全和稳定的关系',
        ),
        'B' => 
        array (
          'name' => '希望你们的关系中不断有变化和新意 ',
        ),
      ),
    ),
    49 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '恋爱时，你一般更喜欢',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '面对面的、口头的交流而不是在网上交流',
        ),
        'B' => 
        array (
          'name' => '更喜欢在网上交流，如微信文字交流',
        ),
      ),
    ),
    50 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '恋爱中你常会站在对方角度去思考而模糊了自己的立场',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '不会',
        ),
      ),
    ),
    51 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '你容易将你的私事和情感',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '和别人分享',
        ),
        'B' => 
        array (
          'name' => '尽可能隐藏',
        ),
      ),
    ),
    52 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '恋爱中，我更偏向于是一个',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '理想主义者',
        ),
        'B' => 
        array (
          'name' => '现实主义者',
        ),
      ),
    ),
    53 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '当你受委屈时',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '需要找人倾诉',
        ),
        'B' => 
        array (
          'name' => '宁愿憋在心里或匿名写在网上吐嘈',
        ),
      ),
    ),
    54 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '当受到情感上的伤害或挫折时',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '虽然我觉得受伤，但一旦想通，就会很快从阴影中走出来',
        ),
        'B' => 
        array (
          'name' => '我通常让自己的情绪深陷其中，很难走出来',
        ),
      ),
    ),
    55 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '当我不同意恋人的想法时，我更倾向于',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '尽可能避免伤害对方的感情，若是会对对方造成伤害的话，我宁愿不说',
        ),
        'B' => 
        array (
          'name' => '毫无保留地说话，并且对恋人直言直语，因为对的就是对的',
        ),
      ),
    ),
    56 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '情感因素很难左右你的决定',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是',
        ),
        'B' => 
        array (
          'name' => '否',
        ),
      ),
    ),
    57 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '对于应酬中逢场作戏、聪明圆融的人，你的看法是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '不理解，也无法接受人们快速地相熟热络，而又骨底淡薄',
        ),
        'B' => 
        array (
          'name' => '看应酬的目的是什么，只要目的是有益的，这些也都无所谓了',
        ),
      ),
    ),
    58 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '以下哪种朋友圈更容易引发你的好感',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '分享日常生活感受的',
        ),
        'B' => 
        array (
          'name' => '参加各种会议活动的',
        ),
      ),
    ),
    59 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '被邀请参加同学的婚礼，发现婚礼上除了同学都没有认识的人。你是否会觉得有些不自在？',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是',
        ),
        'B' => 
        array (
          'name' => '否',
        ),
      ),
    ),
    60 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '你的朋友换了一件新衣服，或一个新发型，你通常会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '一眼就注意到',
        ),
        'B' => 
        array (
          'name' => '可能会感觉不太一样，却不知道哪里变化了',
        ),
      ),
    ),
    61 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '在你的生活方式中，你比较喜欢',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '别出心裁',
        ),
        'B' => 
        array (
          'name' => '根据惯例',
        ),
      ),
    ),
    62 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '你更希望过哪种生活？',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '坐在小木屋门前，眼前是烟波浩渺的湖水',
        ),
        'B' => 
        array (
          'name' => '窗外望去满是繁华',
        ),
      ),
    ),
    63 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '哪种情形更符合你',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '对于传统的东西，我遵循弃其糟粕，取其精华的原则',
        ),
        'B' => 
        array (
          'name' => '必须承认潜意识中我还是会受到传统观念的束缚，但也会因此而受益',
        ),
      ),
    ),
    64 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '你跟男朋友感情很好，但是男方父母不待见你，你会考虑分手吗？',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '会，因为爱情是爱情，婚姻是婚姻',
        ),
        'B' => 
        array (
          'name' => '不会，因为感情是两个人的事，只要男朋友对我好就行。',
        ),
      ),
    ),
    65 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '下列两个异性，如果让你选择，你最终会选择和谁在一起？',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '家庭背景和经济实力门当户对，但不心动的人',
        ),
        'B' => 
        array (
          'name' => '很有感觉，但家庭背景和经济实力和你有差距的人',
        ),
      ),
    ),
    66 => 
    array (
      'groupName' => '爱情婚姻观',
      'matter' => '你已经完成爱情婚姻观的测试，接下来
还需测试您的职业性格，请继续',
      'scoreValue' => '',
      'matterImg' => 'https://oss.1cece.top/storage/uploads/20231209/1e5a6fd9b84514203ad6e64412316a07.jpg',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '继续测试',
        ),
      ),
    ),
    67 => 
    array (
      'groupName' => '职业性格',
      'matter' => '如果让你完成一个手工，你希望随心所欲地创作',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的，这样才可以让我有所发挥',
        ),
        'B' => 
        array (
          'name' => '不是的，没有相应的参考样式，我会感觉很难',
        ),
      ),
    ),
    68 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你更喜欢怎样的氛围下工作:',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '相处和睦而舒服',
        ),
        'B' => 
        array (
          'name' => '有竞争有挑战',
        ),
      ),
    ),
    69 => 
    array (
      'groupName' => '职业性格',
      'matter' => '周末或者假期，你一般:',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '经常会睡到中午，一天只吃两餐',
        ),
        'B' => 
        array (
          'name' => '也会早早起床，保持一日三餐的规律性',
        ),
      ),
    ),
    70 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你在工作中',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '会关注周围发生的任何事',
        ),
        'B' => 
        array (
          'name' => '一般只关注自己的工作',
        ),
      ),
    ),
    71 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你有时候会心血来潮做一件事情 ',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '极少会这样',
        ),
      ),
    ),
    72 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你不会为了你所在的群体利益而牺牲自己的利益',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是',
        ),
        'B' => 
        array (
          'name' => '否',
        ),
      ),
    ),
    73 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你习惯投入更多的注意力在...上',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '(这)是什么',
        ),
        'B' => 
        array (
          'name' => '为什么(会是这样)',
        ),
      ),
    ),
    74 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你的兴趣',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '很广泛，但不太深入',
        ),
        'B' => 
        array (
          'name' => '会对某些非常感兴趣的深入研究',
        ),
      ),
    ),
    75 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你一般会',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '先把工作或作业完成好再玩',
        ),
        'B' => 
        array (
          'name' => '尽可能忙里偷闲地娱乐',
        ),
      ),
    ),
    76 => 
    array (
      'groupName' => '职业性格',
      'matter' => '在做某些很多人在做的事情时，你比较喜欢',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '以一般人所接受的方式进行',
        ),
        'B' => 
        array (
          'name' => '以自创的方式进行',
        ),
      ),
    ),
    77 => 
    array (
      'groupName' => '职业性格',
      'matter' => '大多时候，你的书桌或办公桌面物件的摆放更多是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '有序的',
        ),
        'B' => 
        array (
          'name' => '随意的',
        ),
      ),
    ),
    78 => 
    array (
      'groupName' => '职业性格',
      'matter' => '对你来说，同时进行多项任务不是件难事',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的，甚至可能会享受其中',
        ),
        'B' => 
        array (
          'name' => '不是的，这样会打乱我做事的节奏',
        ),
      ),
    ),
    79 => 
    array (
      'groupName' => '职业性格',
      'matter' => '童年上学时',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '爱主动举手提问或回答问题',
        ),
        'B' => 
        array (
          'name' => '只有被老师点名时才发言',
        ),
      ),
    ),
    80 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你是个意志坚强的人吗',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '不是的，我还有挺多软弱退缩的时候',
        ),
      ),
    ),
    81 => 
    array (
      'groupName' => '职业性格',
      'matter' => '在和别人合作做事的时候，你最怕别人说',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '根据我的经验',
        ),
        'B' => 
        array (
          'name' => '据我推理',
        ),
      ),
    ),
    82 => 
    array (
      'groupName' => '职业性格',
      'matter' => '哪种更符合你',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '过于抽象，因此可能在必要的后续行动上不切实际',
        ),
        'B' => 
        array (
          'name' => '谨小慎微，可能导致视野不开阔',
        ),
      ),
    ),
    83 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你容易陷入情绪化不能自拔吗',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是',
        ),
        'B' => 
        array (
          'name' => '否',
        ),
      ),
    ),
    84 => 
    array (
      'groupName' => '职业性格',
      'matter' => '当你专注做某件事情的时候',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '需要不时停下来休息',
        ),
        'B' => 
        array (
          'name' => '不希望受到任何干扰，持续下去',
        ),
      ),
    ),
    85 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你参与社交聚会时',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '总是能认识新朋友',
        ),
        'B' => 
        array (
          'name' => '只跟几个熟识好友呆在一起',
        ),
      ),
    ),
    86 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你会倾向',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '在自己有兴趣的范畴，持续积累丰富的经验',
        ),
        'B' => 
        array (
          'name' => '在不同的领域拥有各式各样不同的经验',
        ),
      ),
    ),
    87 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你容易被强烈的情感影响',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是这样',
        ),
        'B' => 
        array (
          'name' => '不会',
        ),
      ),
    ),
    88 => 
    array (
      'groupName' => '职业性格',
      'matter' => '他人违反规定，你更可能',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '按照章程办事，因为是我的职责要求',
        ),
        'B' => 
        array (
          'name' => '视实际情况而定，因为规矩是死的，而人是活的',
        ),
      ),
    ),
    89 => 
    array (
      'groupName' => '职业性格',
      'matter' => '很容易与他人成为朋友',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的，不管对方是谁，我都能和他和睦相处',
        ),
        'B' => 
        array (
          'name' => '没有必要和所有人都成为朋友，有几个真正的知己就可以',
        ),
      ),
    ),
    90 => 
    array (
      'groupName' => '职业性格',
      'matter' => '我喜欢的处事方式是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '坚持那些已经有效的做法',
        ),
        'B' => 
        array (
          'name' => '分析哪些仍有错或不完善，优化以往的做法',
        ),
      ),
    ),
    91 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你更擅长',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '运用逻辑、分析及批判性思维来解决问题',
        ),
        'B' => 
        array (
          'name' => '运用人际关系解决问题',
        ),
      ),
    ),
    92 => 
    array (
      'groupName' => '职业性格',
      'matter' => '一个人应该',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '考虑人生的真正意义',
        ),
        'B' => 
        array (
          'name' => '踏踏实实地工作和学习',
        ),
      ),
    ),
    93 => 
    array (
      'groupName' => '职业性格',
      'matter' => '在一群人中，你是那个:',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '擅于把气氛营造出来的人',
        ),
        'B' => 
        array (
          'name' => '不多说话，更像以”观察者“身份参与的人',
        ),
      ),
    ),
    94 => 
    array (
      'groupName' => '职业性格',
      'matter' => '如你有一个约见，你是习惯临场发挥还是事先周密准备',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '随机应变，临场发挥',
        ),
        'B' => 
        array (
          'name' => '不周密准备我不安心',
        ),
      ),
    ),
    95 => 
    array (
      'groupName' => '职业性格',
      'matter' => '请选择更合适描述你的词语',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '擅长在变化中寻求挑战',
        ),
        'B' => 
        array (
          'name' => '习惯一步一个脚印稳步前行',
        ),
      ),
    ),
    96 => 
    array (
      'groupName' => '职业性格',
      'matter' => '请选择更合适描述你的词语',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '我通常边说话，边思考',
        ),
        'B' => 
        array (
          'name' => '我在说话前，通常会思考要说的话',
        ),
      ),
    ),
    97 => 
    array (
      'groupName' => '职业性格',
      'matter' => '无所事事的时候，你会:',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '觉得很无聊，有种浪费生命的感觉',
        ),
        'B' => 
        array (
          'name' => '很享受这种闲暇的情致',
        ),
      ),
    ),
    98 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你比较钦羡',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '循规蹈矩、不引人注目的人',
        ),
        'B' => 
        array (
          'name' => '特立独行的人',
        ),
      ),
    ),
    99 => 
    array (
      'groupName' => '职业性格',
      'matter' => '在人际交往时，你:',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '希望在人际关系中占据主导地位',
        ),
        'B' => 
        array (
          'name' => '顺其自然，不温不火，相对被动',
        ),
      ),
    ),
    100 => 
    array (
      'groupName' => '职业性格',
      'matter' => '电话铃声突然响起或类似这样的突发性事件，你习惯最先做出回应',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的',
        ),
        'B' => 
        array (
          'name' => '不会',
        ),
      ),
    ),
    101 => 
    array (
      'groupName' => '职业性格',
      'matter' => '你需要有挑战的，高技术含量的工作',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '不是的',
        ),
        'B' => 
        array (
          'name' => '是的',
        ),
      ),
    ),
    102 => 
    array (
      'groupName' => '职业性格',
      'matter' => '喜欢清闲的生活',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '是的，我喜欢轻轻松松的人生',
        ),
        'B' => 
        array (
          'name' => '我喜欢有挑战的人生，不断给自己更高的目标',
        ),
      ),
    ),
    103 => 
    array (
      'groupName' => '职业性格',
      'matter' => '我更愿意被看作是',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '务实的人',
        ),
        'B' => 
        array (
          'name' => '有想象力、有灵感的人',
        ),
      ),
    ),
    104 => 
    array (
      'groupName' => '职业性格',
      'matter' => '做某个项目，你更喜欢',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '最后完成的结果',
        ),
        'B' => 
        array (
          'name' => '享受过程',
        ),
      ),
    ),
    105 => 
    array (
      'groupName' => '职业性格',
      'matter' => '终测题：你更像下面的哪一边',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '<p>相比推测，更重视证据，并相信自己的亲身经历和经验</p><p>重视规则和标准，擅长设定目标、制定决策和组织资源来完成任务。</p><p>希望实现高效的生产力，认为只有将人员和系统合理地组织起来，才能最好地实现这一目标。</p>',
        ),
        'B' => 
        array (
          'name' => '<p>乐于了解游戏规则，更看重可预测性而非想象力，并且依靠过去的经验来指导自己。</p><p>逻辑性强，有条不紊，享受利用逐步推理的方法来解决问题的任务。</p><p>对细节一丝不苟，对事物进行仔细检查以确保其正确性。</p>',
        ),
      ),
    ),
  ),
);
