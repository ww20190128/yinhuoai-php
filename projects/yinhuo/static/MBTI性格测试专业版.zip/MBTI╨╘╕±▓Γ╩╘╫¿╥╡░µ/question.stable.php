<?php
return array (
  1 => 
  array (
    'groupName' => '',
    'matter' => '当你要外出一整天，你会：',
    'scoreValue' => 'jp',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '计划你要做什么和在什么时候做',
      ),
      'B' => 
      array (
        'name' => '说去就去',
      ),
    ),
  ),
  2 => 
  array (
    'groupName' => '',
    'matter' => '你认为自己是一个：',
    'scoreValue' => 'pj',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '较为随兴所至的人',
      ),
      'B' => 
      array (
        'name' => '较为有条理的人',
      ),
    ),
  ),
  3 => 
  array (
    'groupName' => '',
    'matter' => '假如你是一位老师，你会选教：',
    'scoreValue' => 'sn',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '以事实为主的课程',
      ),
      'B' => 
      array (
        'name' => '涉及理论的课程',
      ),
    ),
  ),
  4 => 
  array (
    'groupName' => '',
    'matter' => '你通常：',
    'scoreValue' => 'ei',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '与人容易混熟',
      ),
      'B' => 
      array (
        'name' => '比较沉静或矜持',
      ),
    ),
  ),
  5 => 
  array (
    'groupName' => '',
    'matter' => '一般来说，你和哪些人比较合得来？',
    'scoreValue' => 'ns',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '富于想象力的人',
      ),
      'B' => 
      array (
        'name' => '现实的人',
      ),
    ),
  ),
  6 => 
  array (
    'groupName' => '',
    'matter' => '你是否经常让：',
    'scoreValue' => 'ft',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '你的情感支配你的理智',
      ),
      'B' => 
      array (
        'name' => '你的理智主宰你的情感',
      ),
    ),
  ),
  7 => 
  array (
    'groupName' => '',
    'matter' => '处理许多事情上，你会喜欢：',
    'scoreValue' => 'pj',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '凭兴所至行事',
      ),
      'B' => 
      array (
        'name' => '按照计划行事',
      ),
    ),
  ),
  8 => 
  array (
    'groupName' => '',
    'matter' => '你是否：',
    'scoreValue' => 'ei',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '容易让人了解',
      ),
      'B' => 
      array (
        'name' => '难于让人了解',
      ),
    ),
  ),
  9 => 
  array (
    'groupName' => '',
    'matter' => '按照程序表做事：',
    'scoreValue' => 'jp',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '合你心意',
      ),
      'B' => 
      array (
        'name' => '令你感到束缚',
      ),
    ),
  ),
  10 => 
  array (
    'groupName' => '',
    'matter' => '当你有一份特别的任务，你会喜欢：',
    'scoreValue' => 'jp',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '开始前小心组织计划',
      ),
      'B' => 
      array (
        'name' => '边做边找须做什么',
      ),
    ),
  ),
  11 => 
  array (
    'groupName' => '',
    'matter' => '在大多数情况下，你会选择：',
    'scoreValue' => 'pj',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '顺其自然',
      ),
      'B' => 
      array (
        'name' => '按照程序做事',
      ),
    ),
  ),
  12 => 
  array (
    'groupName' => '',
    'matter' => '大多数人会说你是一个：',
    'scoreValue' => 'ie',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '重视自我隐私的人',
      ),
      'B' => 
      array (
        'name' => '非常坦率开放的人',
      ),
    ),
  ),
  13 => 
  array (
    'groupName' => '',
    'matter' => '你宁愿被人认为是一个：',
    'scoreValue' => 'sn',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '实事求是的人',
      ),
      'B' => 
      array (
        'name' => '机灵的人',
      ),
    ),
  ),
  14 => 
  array (
    'groupName' => '',
    'matter' => '在一大群人当中，通常是：',
    'scoreValue' => 'ei',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '你介绍大家认识',
      ),
      'B' => 
      array (
        'name' => '别人介绍你',
      ),
    ),
  ),
  15 => 
  array (
    'groupName' => '',
    'matter' => '你会跟哪些人做朋友？',
    'scoreValue' => 'ns',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '常提出新注意的',
      ),
      'B' => 
      array (
        'name' => '脚踏实地的',
      ),
    ),
  ),
  16 => 
  array (
    'groupName' => '',
    'matter' => '你倾向：',
    'scoreValue' => 'ft',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '重视感情多于逻辑',
      ),
      'B' => 
      array (
        'name' => '重视逻辑多于感情',
      ),
    ),
  ),
  17 => 
  array (
    'groupName' => '',
    'matter' => '你比较喜欢：',
    'scoreValue' => 'pj',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '坐观事情发展才作计划',
      ),
      'B' => 
      array (
        'name' => '很早就作计划',
      ),
    ),
  ),
  18 => 
  array (
    'groupName' => '',
    'matter' => '你喜欢花很多的时间：',
    'scoreValue' => 'ie',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '一个人独处',
      ),
      'B' => 
      array (
        'name' => '合别人在一起',
      ),
    ),
  ),
  19 => 
  array (
    'groupName' => '',
    'matter' => '与很多人一起会：',
    'scoreValue' => 'ei',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '令你活力培增',
      ),
      'B' => 
      array (
        'name' => '常常令你心力憔悴',
      ),
    ),
  ),
  20 => 
  array (
    'groupName' => '',
    'matter' => '你比较喜欢：',
    'scoreValue' => 'jp',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '很早便把约会、社交聚集等事情安排妥当',
      ),
      'B' => 
      array (
        'name' => '无拘无束，看当时有什么好玩就做什么',
      ),
    ),
  ),
  21 => 
  array (
    'groupName' => '',
    'matter' => '计划一个旅程时，你较喜欢：',
    'scoreValue' => 'pj',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '大部分的时间都是跟当天的感觉行事',
      ),
      'B' => 
      array (
        'name' => '事先知道大部分的日子会做什么',
      ),
    ),
  ),
  22 => 
  array (
    'groupName' => '',
    'matter' => '在社交聚会中，你：',
    'scoreValue' => 'ie',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '有时感到郁闷',
      ),
      'B' => 
      array (
        'name' => '常常乐在其中',
      ),
    ),
  ),
  23 => 
  array (
    'groupName' => '',
    'matter' => '你通常：',
    'scoreValue' => 'ei',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '和别人容易混熟',
      ),
      'B' => 
      array (
        'name' => '趋向自处一隅',
      ),
    ),
  ),
  24 => 
  array (
    'groupName' => '',
    'matter' => '哪些人会更吸引你？',
    'scoreValue' => 'ns',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '一个思想敏捷及非常聪颖的人',
      ),
      'B' => 
      array (
        'name' => '实事求是，具丰富常识的人',
      ),
    ),
  ),
  25 => 
  array (
    'groupName' => '',
    'matter' => '在日常工作中，你会：',
    'scoreValue' => 'pj',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '颇为喜欢处理迫使你分秒必争的突发',
      ),
      'B' => 
      array (
        'name' => '通常预先计划，以免要在压力下工作',
      ),
    ),
  ),
  26 => 
  array (
    'groupName' => '',
    'matter' => '你认为别人一般：',
    'scoreValue' => 'ie',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '要花很长时间才认识你',
      ),
      'B' => 
      array (
        'name' => '用很短的时间便认识你',
      ),
    ),
  ),
  27 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ie',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '注重隐私',
      ),
      'B' => 
      array (
        'name' => '坦率开放',
      ),
    ),
  ),
  28 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'jp',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '预先安排的',
      ),
      'B' => 
      array (
        'name' => '无计划的',
      ),
    ),
  ),
  29 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ns',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '抽象',
      ),
      'B' => 
      array (
        'name' => '具体',
      ),
    ),
  ),
  30 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ft',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '温柔',
      ),
      'B' => 
      array (
        'name' => '坚定',
      ),
    ),
  ),
  31 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'tf',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '思考',
      ),
      'B' => 
      array (
        'name' => '感受',
      ),
    ),
  ),
  32 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'sn',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '事实',
      ),
      'B' => 
      array (
        'name' => '意念',
      ),
    ),
  ),
  33 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'pj',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '冲动',
      ),
      'B' => 
      array (
        'name' => '决定',
      ),
    ),
  ),
  34 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ei',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '热衷',
      ),
      'B' => 
      array (
        'name' => '文静',
      ),
    ),
  ),
  35 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ie',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '文静',
      ),
      'B' => 
      array (
        'name' => '外向',
      ),
    ),
  ),
  36 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'jp',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '有系统',
      ),
      'B' => 
      array (
        'name' => '随意',
      ),
    ),
  ),
  37 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ns',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '理论',
      ),
      'B' => 
      array (
        'name' => '肯定',
      ),
    ),
  ),
  38 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ft',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '敏感',
      ),
      'B' => 
      array (
        'name' => '公正',
      ),
    ),
  ),
  39 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'tf',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '令人信服',
      ),
      'B' => 
      array (
        'name' => '感人的',
      ),
    ),
  ),
  40 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'sn',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '声明',
      ),
      'B' => 
      array (
        'name' => '概念',
      ),
    ),
  ),
  41 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'pj',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '不受约束',
      ),
      'B' => 
      array (
        'name' => '预先安排',
      ),
    ),
  ),
  42 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ie',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '矜持',
      ),
      'B' => 
      array (
        'name' => '健谈',
      ),
    ),
  ),
  43 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'jp',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '有条不紊',
      ),
      'B' => 
      array (
        'name' => '不拘小节',
      ),
    ),
  ),
  44 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ns',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '意念',
      ),
      'B' => 
      array (
        'name' => '实况',
      ),
    ),
  ),
  45 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ft',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '同情怜悯',
      ),
      'B' => 
      array (
        'name' => '远见',
      ),
    ),
  ),
  46 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'tf',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '利益',
      ),
      'B' => 
      array (
        'name' => '祝福',
      ),
    ),
  ),
  47 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'sn',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '务实的',
      ),
      'B' => 
      array (
        'name' => '理论的',
      ),
    ),
  ),
  48 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ie',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '朋友不多',
      ),
      'B' => 
      array (
        'name' => '朋友众多',
      ),
    ),
  ),
  49 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'jp',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '有系统',
      ),
      'B' => 
      array (
        'name' => '即兴',
      ),
    ),
  ),
  50 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ns',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '富想象的',
      ),
      'B' => 
      array (
        'name' => '以事论事',
      ),
    ),
  ),
  51 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ft',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '亲切的',
      ),
      'B' => 
      array (
        'name' => '客观的',
      ),
    ),
  ),
  52 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'tf',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '客观的',
      ),
      'B' => 
      array (
        'name' => '热情的',
      ),
    ),
  ),
  53 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'sn',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '建造',
      ),
      'B' => 
      array (
        'name' => '发明',
      ),
    ),
  ),
  54 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ie',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '文静',
      ),
      'B' => 
      array (
        'name' => '爱合群',
      ),
    ),
  ),
  55 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ns',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '理论',
      ),
      'B' => 
      array (
        'name' => '事实',
      ),
    ),
  ),
  56 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'ft',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '富同情',
      ),
      'B' => 
      array (
        'name' => '合逻辑',
      ),
    ),
  ),
  57 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'tf',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '具分析力',
      ),
      'B' => 
      array (
        'name' => '多愁善感',
      ),
    ),
  ),
  58 => 
  array (
    'groupName' => '',
    'matter' => '下面哪项符合您?',
    'scoreValue' => 'sn',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '合情合理',
      ),
      'B' => 
      array (
        'name' => '令人着迷',
      ),
    ),
  ),
  59 => 
  array (
    'groupName' => '',
    'matter' => '当你要在一个星期内完成一个大项目，你在开始的时候会：',
    'scoreValue' => 'jp',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '提前做好计划和准备',
      ),
      'B' => 
      array (
        'name' => '马上动工',
      ),
    ),
  ),
  60 => 
  array (
    'groupName' => '',
    'matter' => '在社交场合中，你会感觉更自在：',
    'scoreValue' => 'ie',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '及某些人很难打开话匣儿和保持对话',
      ),
      'B' => 
      array (
        'name' => '和多少人能够从容不迫的畅谈',
      ),
    ),
  ),
  61 => 
  array (
    'groupName' => '',
    'matter' => '要做许多人也做的事，你比较喜欢：',
    'scoreValue' => 'es',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '按照一般认可的方法去做',
      ),
      'B' => 
      array (
        'name' => '构想一个自己的想法',
      ),
    ),
  ),
  62 => 
  array (
    'groupName' => '',
    'matter' => '你刚认识的朋友能否说出你的兴趣？',
    'scoreValue' => 'ei',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '马上可以',
      ),
      'B' => 
      array (
        'name' => '要等他们了解你之后才可以',
      ),
    ),
  ),
  63 => 
  array (
    'groupName' => '',
    'matter' => '你通常较喜欢的科目是',
    'scoreValue' => 'ns',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '讲授概念和原则的',
      ),
      'B' => 
      array (
        'name' => '讲授事实和数据的',
      ),
    ),
  ),
  64 => 
  array (
    'groupName' => '',
    'matter' => '哪个是较高的赞誉，或称许为？',
    'scoreValue' => 'ft',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '一贯善感的人',
      ),
      'B' => 
      array (
        'name' => '一贯理性的人',
      ),
    ),
  ),
  65 => 
  array (
    'groupName' => '',
    'matter' => '你认为按照程序表做事',
    'scoreValue' => 'pj',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '有时是需要的，但一般来说你不大喜欢这样做，或是',
      ),
      'B' => 
      array (
        'name' => '大多数情况下是有帮助而且是你喜欢做的',
      ),
    ),
  ),
  66 => 
  array (
    'groupName' => '',
    'matter' => '和一群人在一起，你通常会选',
    'scoreValue' => 'ie',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '跟你很熟悉的个别人谈话',
      ),
      'B' => 
      array (
        'name' => '参及大伙的谈话',
      ),
    ),
  ),
  67 => 
  array (
    'groupName' => '',
    'matter' => '在社交聚会上，你会',
    'scoreValue' => 'ei',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '是说话很多的一个',
      ),
      'B' => 
      array (
        'name' => '让别人多说话',
      ),
    ),
  ),
  68 => 
  array (
    'groupName' => '',
    'matter' => '把周末期间要完成的事列成清单，这个主意会',
    'scoreValue' => 'jp',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '合你意',
      ),
      'B' => 
      array (
        'name' => '使你提不起劲',
      ),
    ),
  ),
  69 => 
  array (
    'groupName' => '',
    'matter' => '哪个是较高的赞誉，或称许为',
    'scoreValue' => 'tf',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '能干的',
      ),
      'B' => 
      array (
        'name' => '富有同情心',
      ),
    ),
  ),
  70 => 
  array (
    'groupName' => '',
    'matter' => '你通常喜欢',
    'scoreValue' => 'jp',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '事先安排你的社交约会',
      ),
      'B' => 
      array (
        'name' => '随兴之所至做事',
      ),
    ),
  ),
  71 => 
  array (
    'groupName' => '',
    'matter' => '总的说来，要做一个大型作业时，你会选',
    'scoreValue' => 'pj',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '边做边想该做什么',
      ),
      'B' => 
      array (
        'name' => '首先把工作按步细分',
      ),
    ),
  ),
  72 => 
  array (
    'groupName' => '',
    'matter' => '你能否滔滔不绝地及人聊天',
    'scoreValue' => 'ie',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '只限于跟你有共同兴趣的人',
      ),
      'B' => 
      array (
        'name' => '几乎跟任何人都可以',
      ),
    ),
  ),
  73 => 
  array (
    'groupName' => '',
    'matter' => '你会',
    'scoreValue' => 'sn',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '跟随一些证明有效的方法，或是',
      ),
      'B' => 
      array (
        'name' => '分析还有什么毛病，及针对尚未解决的难题',
      ),
    ),
  ),
  74 => 
  array (
    'groupName' => '',
    'matter' => '为乐趣而阅读时，你会',
    'scoreValue' => 'ns',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '喜欢奇特或创新的表达方式',
      ),
      'B' => 
      array (
        'name' => '喜欢作者直话直说',
      ),
    ),
  ),
  75 => 
  array (
    'groupName' => '',
    'matter' => '你宁愿替哪一类上司（或者老师）工作？',
    'scoreValue' => 'tn',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '天性淳良，但常常前后不一的',
      ),
      'B' => 
      array (
        'name' => '言词尖锐但永远合乎逻辑的',
      ),
    ),
  ),
  76 => 
  array (
    'groupName' => '',
    'matter' => '你做事多数是',
    'scoreValue' => 'pj',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '按当天心情去做',
      ),
      'B' => 
      array (
        'name' => '照拟好的程序表去做',
      ),
    ),
  ),
  77 => 
  array (
    'groupName' => '',
    'matter' => '你是否',
    'scoreValue' => 'ei',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '可以和任何人按需求从容地交谈，或是',
      ),
      'B' => 
      array (
        'name' => '只是对某些人或在某种情况下才可以畅所欲言',
      ),
    ),
  ),
  78 => 
  array (
    'groupName' => '',
    'matter' => '要作决定时，你认为比较重要的是',
    'scoreValue' => 'tf',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '据事实衡量',
      ),
      'B' => 
      array (
        'name' => '考虑他人的感受和意见',
      ),
    ),
  ),
  79 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'ns',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '想象的',
      ),
      'B' => 
      array (
        'name' => '真实的',
      ),
    ),
  ),
  80 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'ft',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '仁慈慷慨的',
      ),
      'B' => 
      array (
        'name' => '意志坚定的',
      ),
    ),
  ),
  81 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'tf',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '公正的',
      ),
      'B' => 
      array (
        'name' => '有关怀心',
      ),
    ),
  ),
  82 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'sn',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '制作',
      ),
      'B' => 
      array (
        'name' => '设计',
      ),
    ),
  ),
  83 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'ns',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '可能性',
      ),
      'B' => 
      array (
        'name' => '必然性',
      ),
    ),
  ),
  84 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'ft',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '温柔',
      ),
      'B' => 
      array (
        'name' => '力量',
      ),
    ),
  ),
  85 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'tf',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '实际',
      ),
      'B' => 
      array (
        'name' => '多愁善感',
      ),
    ),
  ),
  86 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'sn',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '制造',
      ),
      'B' => 
      array (
        'name' => '创造',
      ),
    ),
  ),
  87 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'ns',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '新颖的',
      ),
      'B' => 
      array (
        'name' => '已知的',
      ),
    ),
  ),
  88 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'ft',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '同情',
      ),
      'B' => 
      array (
        'name' => '分析',
      ),
    ),
  ),
  89 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'tf',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '坚持己见',
      ),
      'B' => 
      array (
        'name' => '温柔有爱心',
      ),
    ),
  ),
  90 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'sn',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '具体的',
      ),
      'B' => 
      array (
        'name' => '抽象的',
      ),
    ),
  ),
  91 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'ft',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '全心投入',
      ),
      'B' => 
      array (
        'name' => '有关决心的',
      ),
    ),
  ),
  92 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'tf',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '能干',
      ),
      'B' => 
      array (
        'name' => '仁慈',
      ),
    ),
  ),
  93 => 
  array (
    'groupName' => '',
    'matter' => '下面哪些描述更符合您的心意？',
    'scoreValue' => 'sn',
    'selections' => 
    array (
      'A' => 
      array (
        'name' => '实际',
      ),
      'B' => 
      array (
        'name' => '创新',
      ),
    ),
  ),
);