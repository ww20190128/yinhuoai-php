<?php
return array (
  1 => 
  array (
    1 => 
    array (
      'matter' => '我乐于助人|我喜欢把东西拆开，了解其工作原理和运作的奥妙',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    2 => 
    array (
      'matter' => '我喜欢与关注未来的人交往|我喜欢和历史学家交往',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    3 => 
    array (
      'matter' => '我想要每个人都喜欢我|我想要人们崇拜我',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    4 => 
    array (
      'matter' => '我力争第一|我重在参与',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    5 => 
    array (
      'matter' => '我一贯努力工作|我做事进展较慢，但确保成效',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    6 => 
    array (
      'matter' => '我思考自身的长处|我思考有待改进之处',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    7 => 
    array (
      'matter' => '我是一个偏重情感的人|我是一个偏重理智的人',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    8 => 
    array (
      'matter' => '我了解别人的个性特点|我能够接受各种类型的人',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    9 => 
    array (
      'matter' => '主动与人交谈使我为难|与陌生人攀谈使我兴奋',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    10 => 
    array (
      'matter' => '我对生活感觉极好|我认为我自己很能干',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    11 => 
    array (
      'matter' => '我喜欢与人合作|我喜欢个人奋斗',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    12 => 
    array (
      'matter' => '我能使别人有成就感|我能使别人感到我对他们很重要',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    13 => 
    array (
      'matter' => '我按照自己的世界观去生活|我按照自己的理想去生活',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    14 => 
    array (
      'matter' => '成为他人的知己使我满足|我希望成为他人的领导',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    15 => 
    array (
      'matter' => '我不在意别人对我的所作所为怎么看，我做对自己有利的事|我始终清楚别人对我的看法',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    16 => 
    array (
      'matter' => '我致力于发展|我信守自己的价值观',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    17 => 
    array (
      'matter' => '我要自己的生活保持平衡|我希望我的家庭过最好的生活',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    18 => 
    array (
      'matter' => '我每天多次谈到自己对未来的展望|我愿腾出时间思考未来',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    19 => 
    array (
      'matter' => '我能够使别人兴奋起来|我能够使别人平静下来',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    20 => 
    array (
      'matter' => '我一旦作出决定就必须付诸行动|我在行动之前需要确认自己行动无误',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    21 => 
    array (
      'matter' => '我比大多数人更加专心去做要完成的事|我统观全局顺其自然',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    22 => 
    array (
      'matter' => '我认为世上没有巧合，一切都事出有因|对我来说巧合指运气、机遇、侥幸、偶然',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    23 => 
    array (
      'matter' => '我善于交谈|我善于倾听',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    24 => 
    array (
      'matter' => '我喜欢表扬别人|我喜欢受到表扬',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    25 => 
    array (
      'matter' => '我喜欢竞赛|我喜欢工作',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    26 => 
    array (
      'matter' => '我思考问题脚踏实地，善于借助专家寻找正确答案|我思考问题善于创造，且有战略眼光，对规律和问题一目了然',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    27 => 
    array (
      'matter' => '我充满活力，满怀喜悦和欢乐|我了解影响形势的所有因素',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    28 => 
    array (
      'matter' => '我想成为一家大公司的总裁|我为别人牵线搭桥',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    29 => 
    array (
      'matter' => '我有时会威逼别人|我在大人物面前感到渺小',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    30 => 
    array (
      'matter' => '我能设身处地为别着想|我能够爱别人，爱所有的人',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    31 => 
    array (
      'matter' => '我推动别人成功|我使别人快乐',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    32 => 
    array (
      'matter' => '我是一个无忧无虑的人|我比我的朋友、同事更成熟',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    33 => 
    array (
      'matter' => '我尽量与别人一起做事|我喜欢为别人张罗',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    34 => 
    array (
      'matter' => '通过研究我的历史我可以预测未来|我的过去与我的未来无关',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    35 => 
    array (
      'matter' => '我属于超越自我的宏观世界|我是一个脚踏实地的人',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    36 => 
    array (
      'matter' => '我要我的工作和生活融为一体|工作只是一种谋生的手段',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    37 => 
    array (
      'matter' => '有人不喜欢我时，我会感到沮丧|如果自己认为不对的事，就会感到内疚',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    38 => 
    array (
      'matter' => '我组织|我分析',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    39 => 
    array (
      'matter' => '我能把握对别人的谈话要点，使他们感觉良好|我通过倾听，使人们感觉获得理解',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    40 => 
    array (
      'matter' => '我喜欢富于哲理的人|我喜欢和勤奋而富有成效的人交往',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    41 => 
    array (
      'matter' => '我乐于使别人认识其自身的价值|我乐于使别人有成就感',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    42 => 
    array (
      'matter' => '我靠直觉解决问题|我使用来源可靠的准确信息',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    43 => 
    array (
      'matter' => '我对生活持有一种健康的怀疑态度|我相信自己与全人类相连',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    44 => 
    array (
      'matter' => '我的朋友请我讲故事|我的朋友请我出主意',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    45 => 
    array (
      'matter' => '我在上午工作效率最高|我在晚上工作效率最高',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    46 => 
    array (
      'matter' => '我与大多数人比不相上下，无需工作更努力更持久|我精力充沛，始终比大多数人工作更努力，更持久',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    47 => 
    array (
      'matter' => '任何与体育有关的事都会强烈吸引我|任何与人文思想有关的事都会强烈吸引我',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    48 => 
    array (
      'matter' => '我是一个十分整洁的人|我非常固执',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    49 => 
    array (
      'matter' => '我通过与别人分享而成长|我通过学习而成长',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    50 => 
    array (
      'matter' => '我按照自己对未来的书面规划而行动|我走一步，看一步',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    51 => 
    array (
      'matter' => '我注重未来可能取得的成就|我注重应对未来可能发生的事件',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    52 => 
    array (
      'matter' => '我不排斥任何人，从而不伤害他们的感情|我仔细挑选我的朋友',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    53 => 
    array (
      'matter' => '我不自负，不在乎别人是否把我视为可信、专业化或成功人士|别人是否把我视为可信、专业化或成功人士对我很重要',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    54 => 
    array (
      'matter' => '我喜欢了解大战的起因|我喜欢了解50年后的世界经济',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    55 => 
    array (
      'matter' => '我对我生活中遇到的事件进行分析|我对影响我生活的事件充满激情',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    56 => 
    array (
      'matter' => '我通过发挥自身的才干取得进步|我通过克服自身的弱点取得进步',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    57 => 
    array (
      'matter' => '对我来说每件事都必须事先计划|我喜欢顺其自然',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    58 => 
    array (
      'matter' => '我寻找各种不同的做事方法|我确立常规的做事方法',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    59 => 
    array (
      'matter' => '我讨厌爱发脾气的人|我认为必要时可以发脾气',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    60 => 
    array (
      'matter' => '我喜欢放松|我喜欢清扫',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    61 => 
    array (
      'matter' => '有钱就是幸福|有钱不等于幸福',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    62 => 
    array (
      'matter' => '我征求别人的意见|别人征求我的意见',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    63 => 
    array (
      'matter' => '我认为平等对待所有人，并制定明确的规则至关重要|我认为应了解每个人的特点，并进行个别激励',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    64 => 
    array (
      'matter' => '我借助专家寻找正确答案|我对答案和问题一目了然',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    65 => 
    array (
      'matter' => '我非常慷慨地称赞别人|我有选择地称赞别人',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    66 => 
    array (
      'matter' => '我只有在竞争中赢得第一才能感到完全满意|我只要在比赛中名列前茅就感到高兴',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    67 => 
    array (
      'matter' => '我善于使截然不同的人相互合作|我有平等对待人的天赋',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    68 => 
    array (
      'matter' => '我尽量不离开自己舒适的领地|我是一个寻求刺激的人',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    69 => 
    array (
      'matter' => '我能够体会同事的感受|我喜欢和同事们高谈阔论',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    70 => 
    array (
      'matter' => '我关注人们的特点，而不在乎我是否喜欢他们|我不喜欢某些人，他们和我格格不入',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    71 => 
    array (
      'matter' => '我凭感觉进行重要决策|我凭理智进行重要决策',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    72 => 
    array (
      'matter' => '我随着事情的发生采取行动|我分清事情的轻重缓急，然后采取行动',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    73 => 
    array (
      'matter' => '我喜欢每个人|我要每个人都喜欢我',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    74 => 
    array (
      'matter' => '根据当前的需要，我主要专注做好眼前的事|我着眼于未来的发展',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    75 => 
    array (
      'matter' => '我每周设定业绩目标|我的工作根据当日需求而定',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    76 => 
    array (
      'matter' => '我必须强迫自己才能学习|我对自己感兴趣的事能集中注意力',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    77 => 
    array (
      'matter' => '我喜欢要求精确性的工作|我喜欢团队合作',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    78 => 
    array (
      'matter' => '我研究别人的行为根源|我惯于自我反思',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    79 => 
    array (
      'matter' => '我按部就班|我热情洋溢',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    80 => 
    array (
      'matter' => '我对教育满怀热忱|我对消除暴利满怀热忱',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    81 => 
    array (
      'matter' => '我喜欢别人听我讲话|我喜欢听别人讲话',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    82 => 
    array (
      'matter' => '我很会讲故事|我善于辅导',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    83 => 
    array (
      'matter' => '我喜欢讲话|我喜欢思考',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    84 => 
    array (
      'matter' => '我是个完美主义者|我是个实干家',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    85 => 
    array (
      'matter' => '我思考问题脚踏实地,广泛调查分析|我思考问题善于创造，且具有战略眼光',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    86 => 
    array (
      'matter' => '我总是描准最出色的同行去改进自己|我愿意与欣赏我的长处的人交往',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    87 => 
    array (
      'matter' => '我能同时照顾好几件事|我愿意为别人做出牺牲',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    88 => 
    array (
      'matter' => '我善于交际|我喜欢与朋友一道努力工作',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    89 => 
    array (
      'matter' => '我思维敏捷,经常提出独特的观点|我的谈话使人愉快',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    90 => 
    array (
      'matter' => '我热爱学习|我喜欢外出',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    91 => 
    array (
      'matter' => '我喜欢一切按照规章制度办事|我喜欢反复检查，确保一切井井有条',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    92 => 
    array (
      'matter' => '我善于观察人们之间的区别|我平等对待所有人',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    93 => 
    array (
      'matter' => '我的成功之道在于克服弱点，弥补缺陷|我的成功之道在于增强自身的才干',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    94 => 
    array (
      'matter' => '在遇到困难，而必须圆满完成任务时，我往往亲自动手干|在遇到困难，而必须圆满完成任务时，我往往依靠团队成员的各自优势，而不事必躬亲',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    95 => 
    array (
      'matter' => '我的性格外向|在必要时我能够作到开朗大方',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    96 => 
    array (
      'matter' => '我喜欢解释事情|我喜欢做事情',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    97 => 
    array (
      'matter' => '有时也可以歪曲事实|永远没有理由说谎',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    98 => 
    array (
      'matter' => '我的工作已经满负荷|我还有很大潜力',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    99 => 
    array (
      'matter' => '我以严谨著称|我以幽默感著称',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    100 => 
    array (
      'matter' => '我正在创造我的未来|我正在研究我的未来',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    101 => 
    array (
      'matter' => '我喜欢挑战别人|我喜欢鼓励别人',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    102 => 
    array (
      'matter' => '我是一个非常在意隐私的人|我的生活如同一本开启的书',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    103 => 
    array (
      'matter' => '我慷慨|我节俭',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    104 => 
    array (
      'matter' => '我是一名领导者|我是一名很有成就的人',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    105 => 
    array (
      'matter' => '我有时会奉承别人|我为人正直',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    106 => 
    array (
      'matter' => '我能根据需要长时间学习|我能够集中注意力的时间很短',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    107 => 
    array (
      'matter' => '我避免过分赞扬人，因此当我这样做时就显得很有份量|我慷慨地赞扬我的同事',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    108 => 
    array (
      'matter' => '我愿意了解新事物|我的价值观很稳定',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    109 => 
    array (
      'matter' => '我的生活有目的|我的生活充满欢乐',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    110 => 
    array (
      'matter' => '我喜欢富有哲理的讨论|我喜欢制定目标的会议',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    111 => 
    array (
      'matter' => '我喜欢独处|我想念我的朋友',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    112 => 
    array (
      'matter' => '我想象未来|我理解造成当前情形的原因',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    113 => 
    array (
      'matter' => '我能够实事求是地看待自己|我难于坦诚地看待自己',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    114 => 
    array (
      'matter' => '我愿意花大量的时间和朋友们在一起|我喜欢专心做我认为重要的事情',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    115 => 
    array (
      'matter' => '我小时候喜欢和一大帮朋友们一起玩|我小时候循规蹈矩从不给同伴或大人惹麻烦',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    116 => 
    array (
      'matter' => '我喜欢招待别人|我答应别人的事一定要完成',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    117 => 
    array (
      'matter' => '我讨厌受控制|我喜欢制定规矩',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    118 => 
    array (
      'matter' => '我是一个好老师|我是一个好顾问',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    119 => 
    array (
      'matter' => '我躲避大大咧咧的人|我不与不诚实的人交往',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    120 => 
    array (
      'matter' => '情况不明时我会向心中有数的人求教|无论何时何地我总能悟出该做什么',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    121 => 
    array (
      'matter' => '目标不明的人使我厌烦|我不喜欢和无法放松的人相处',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    122 => 
    array (
      'matter' => '我厌恶期限|我的责任感给我动力',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    123 => 
    array (
      'matter' => '我鼓励别人|我强化别人',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    124 => 
    array (
      'matter' => '我过于轻信别人|我过于雄心勃勃',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    125 => 
    array (
      'matter' => '过去发生的事激励我|未来可能取得的成就激励我',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    126 => 
    array (
      'matter' => '最后一刻压力使我思想高度集中|当我能提前完成任务时，我的思维更清晰',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    127 => 
    array (
      'matter' => '我认为只要环境合适，大多数人都会偷窃|我认为偷窃的人应受到惩罚',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    128 => 
    array (
      'matter' => '我的最大愿望是做自己热爱的工作|我的最大需求是被别人接受',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    129 => 
    array (
      'matter' => '我是一个通情达理的人|我是一个有责任心的人',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    130 => 
    array (
      'matter' => '我主要关注此时此地|我通过研究过去，增长见识',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    131 => 
    array (
      'matter' => '我尽力而为使我感到满足|我立志有所建树',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    132 => 
    array (
      'matter' => '我有强烈的求知欲|我需要被别人认知和理解',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    133 => 
    array (
      'matter' => '我经常考虑因果关系|我遇到事情及时应对',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    134 => 
    array (
      'matter' => '寻找失败的原因|享受目前的成功',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    135 => 
    array (
      'matter' => '我喜欢收藏|我只收集我认为十分精美或特别有价值的东西',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    136 => 
    array (
      'matter' => '我常常能提出建设性的意见|当解决了难题、排除了故障时我感到特有成就感',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    137 => 
    array (
      'matter' => '我待人随和|我善于发挥不同的人的长处',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    138 => 
    array (
      'matter' => '我花较多的时间考虑如何取得竞争优势|我花更多时间考虑如何应对未来可能发生的问题',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    139 => 
    array (
      'matter' => '我认为竞争才能发挥人的最大潜能，所以我刺激我的员工相互竞争|我能使很多人在一起同甘共苦相互合作，并建立很深的友谊',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    140 => 
    array (
      'matter' => '我常常从失败中总结教训|我只关注如何把我最擅长的事做得尽善尽美',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    141 => 
    array (
      'matter' => '我尽力使别人发挥其特长|我尽力使每个人得到进步',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    142 => 
    array (
      'matter' => '把晚间、周末工作时间加起来，我通常一周工作40-50小时|把晚间、周末工作时间加起来，我通常一周工作60超过小时',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    143 => 
    array (
      'matter' => '我轻松愉快|我严肃认真',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    144 => 
    array (
      'matter' => '开始新任务对我很容易|我的问题是做事有始无终',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    145 => 
    array (
      'matter' => '我能和所有的人和睦相处|我仔细分析我的合作伙伴,尽可能了解每个人的个性和背景',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    146 => 
    array (
      'matter' => '我兴趣广泛，好奇心强|我专注把自己感兴趣的事做好',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    147 => 
    array (
      'matter' => '我观察生活|我主宰自己的生活',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    148 => 
    array (
      'matter' => '为了解决一个问题，我常锲而不舍地长时间工作|我最多只能集中精力工作或学习一个小时左右',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    149 => 
    array (
      'matter' => '我的成就非凡|我一贯创造积极成果',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    150 => 
    array (
      'matter' => '我比别人更机智|我在很多人面前感到渺小',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    151 => 
    array (
      'matter' => '我善于高效率地同时做几件事|我习惯于一次只做一件事',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    152 => 
    array (
      'matter' => '我希望经常与我的上司和同事沟通|我希望有更多的自己独立支配的时间',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    153 => 
    array (
      'matter' => '我善于构思并发起一个新项目|我善于组织落实',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    154 => 
    array (
      'matter' => '我经常思考数字|我喜欢思考宏观形象的事情',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    155 => 
    array (
      'matter' => '我偏爱讨论思想|我偏爱体育运动',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    156 => 
    array (
      'matter' => '我的词汇富于哲理|我的词汇偏重实用',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    157 => 
    array (
      'matter' => '我使用简短的词汇|我常用复杂抽象的词汇',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    158 => 
    array (
      'matter' => '我的大脑不停地思考|我的身体需要经常活动',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    159 => 
    array (
      'matter' => '我喜欢听讲|我喜欢小组讨论',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    160 => 
    array (
      'matter' => '帮助别人解决难题，排除故障使我感到快乐|从数据中发现规律使我感到兴奋',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    161 => 
    array (
      'matter' => '我关注分析时事|我不花时间去关注时事',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    162 => 
    array (
      'matter' => '我总能及时完成任务|我言而有信，说到做到',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    163 => 
    array (
      'matter' => '一个新创意会使我激动不已|完成一件交给我的任务会使我激动不已',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    164 => 
    array (
      'matter' => '和别人一起时我觉得我的点子最多|我喜欢和别人一起讨论解决问题的办法',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    165 => 
    array (
      'matter' => '我能详细解释复杂过程|我有化繁为简的天赋',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    166 => 
    array (
      'matter' => '我能一晚读完200页的书|我阅读速度缓慢，因为我要琢磨理解书中的内容',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    167 => 
    array (
      'matter' => '取胜最重要|按规矩做事最重要',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    168 => 
    array (
      'matter' => '我的哲学指引我的生活|我能主导自己的生活',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    169 => 
    array (
      'matter' => '我每周至少花5个小时独自思考|我喜欢和别人在一起',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    170 => 
    array (
      'matter' => '我了解自身长处超过弱点|我了解自身弱点超过长处',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    171 => 
    array (
      'matter' => '我不在乎别人是否喜欢我|我热爱人们',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    172 => 
    array (
      'matter' => '我喜欢和别人谈起我的旅行经历|我不断策划我的下一个旅行目标',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    173 => 
    array (
      'matter' => '我经常以我的亲身经历教育别人|我喜欢树立榜样激励别人',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    174 => 
    array (
      'matter' => '我认为一个好的领导就是要能够调动别人做事|我认为一个好的领导就是要帮助别人更好地做事',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    175 => 
    array (
      'matter' => '我善于处理纷繁复杂的事务|我喜欢制定统一的常规制度',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    176 => 
    array (
      'matter' => '我习惯于根据统计数字预测未来|我习惯于根据当前形势预测未来',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    177 => 
    array (
      'matter' => '我特别善于通过例举过去已取得的成就来鼓舞别人|我特别善于通过描绘未来远景鼓励别人',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    178 => 
    array (
      'matter' => '我有几个特别要好的老朋友|我认识的很多朋友，但几乎没有交情很深的',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    179 => 
    array (
      'matter' => '我习惯于事先想好将要采购商品的标准，只要看到基本符合我需求的商品立刻就买|我事先不考虑太多，到了商场现场，调查一遍之后，再决定购买',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
    180 => 
    array (
      'matter' => '遇到故障或困难时，我常常一马当先|遇到故障或困难时,我往往首先想到找个能人来解决',
      'scoreValue' => '',
      'selections' => 
      array (
        'A' => 
        array (
          'name' => '特别同意',
        ),
        'B' => 
        array (
          'name' => '比较同意',
        ),
        'C' => 
        array (
          'name' => '居中',
        ),
        'D' => 
        array (
          'name' => '比较同意',
        ),
        'E' => 
        array (
          'name' => '特别同意',
        ),
      ),
    ),
  ),
);
