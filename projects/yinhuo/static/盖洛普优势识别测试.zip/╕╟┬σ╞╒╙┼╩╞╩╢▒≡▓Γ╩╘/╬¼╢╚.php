<?php
return array (
	'执行力' => array (
				'描述' => '执行力才干主题可帮助您化想法为现实。',
				'维度图标' => 'https://oss.1cece.top/storage/Goods/20230706/9e3d53469ecd64d6f2c8b244feac7a07.png',
				'维度颜色' => '#7a2381',
				'标题颜色' => '#7a2381',
				'排序图标' => 'https://oss.1cece.top/storage/Goods/20230706/4c46a1aaaac164f55294b4d79e23784c.png',
		),
	'战略思维' => array (
				'描述' => '战略思维才干主题可帮助您获取和分析信息，作出更佳决策。',
				'维度图标' => 'https://oss.1cece.top/storage/Goods/20230706/980178f403eca33d482c0164049e1bc5.png',
				'维度颜色' => '#01945d',
				'标题颜色' => '#01945d',
				'排序图标' => 'https://oss.1cece.top/storage/Goods/20230706/4256b8238864698d2ec02235629cc738.png',
		),
	'关系建立' => array (
				'描述' => '关系建立才干主题可帮助您建立牢固关系，将团队凝聚到一起。',
				'维度图标' => 'https://oss.1cece.top/storage/Goods/20230710/df80bb44b9d1ace759b4debe917ec462.png',
				'维度颜色' => '#0170cc',
				'标题颜色' => '#0170cc',
				'排序图标' => 'https://oss.1cece.top/storage/Goods/20230710/b3370e08c59e22465212be7e5034ab01.png',
		),
	'影响力' => array (
				'描述' => '影响力才干主题可帮助您掌控局势、发表观点并确保他人意见得以表达。',
				'维度图标' => 'https://oss.1cece.top/storage/Goods/20230706/265996772e8258c74f427195e7d6c3fc.png',
				'维度颜色' => '#ea7201',
				'标题颜色' => '#ea7201',
				'排序图标' => 'https://oss.1cece.top/storage/Goods/20230706/48652cf1088e859df9dae68f19b417d3.png',
		),
	
);